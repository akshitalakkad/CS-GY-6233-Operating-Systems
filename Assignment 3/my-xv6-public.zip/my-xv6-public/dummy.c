#include "types.h"
#include "user.h"
#include "stat.h"


int main(int argc, char *argv[]){
        // Get the options (-c, -d, -u, some combinations of them, or none at all)
        // ... ...

        // Figure out whether the input is comng from a file
        // whose name is provided as a command line argument like
        //      myuniq -c -d sorteddepts.lst
        // or from the stdin like
        //      mycut .... | mysort ... | myuniq -c -d
        // ... ...

        // You may assume the input data are all sorted.
        // Read and record two lines (if any) from input and compare them.
        // Let's call them prev and curr.
        // If they are the same, update the number of repeats;
        // If they are different, output the prev according the options (-c, -d, or -u)
        // Keey doing this until hitting the end of the input.
        // ... ...
        char *delivery = "";
        int c_check = 0;
        int d_check = 0;
        int u_check = 0;
        char ch;
        int indexer = 0;
        while((ch  = getopt(argc, argv, "cdu"))!= EOF ){
                switch(ch){
                        case 'c': // counts how many times it appears
                                c_check = 1;
                                break;
                        case 'd': //print duplicates
                                d_check = 1;
                                break;
                        case 'u': //
                                 u_check = 1;
                                break;
                        default:
                                return 0;
 }
        }
        argc -= optind;
        argv += optind;

        FILE *data;
        switch(argc){
        case 0:
                data = stdin;
                break;
        case 1:
                data = fopen(argv[indexer],"r");
                break;
        default:
                printf("Can usage: myuniq [-c | -du] [-f fields] [-s chars] [input [output]]\n");
        }
        char prev[200];
        char current[200];
        fgets(prev, 200, data);
        int num = 1;
        while(fgets(current, 200, data) != NULL)
        {
                if(strcmp(prev,current)==0)
                {
                        num++;
                }
                else
                {
                if(u_check == 1 && d_check == 1)
                {
                        num = 0;
                        printf("not possible\n");
                        break;
                }
                if(c_check == 1)
                {
                        printf("%d ",num);
                }
                if(d_check != 1 && u_check !=1)
                {
                        printf("\n");
                }
                if(d_check == 1 && u_check != 1)
                {
                        if(num > 1)
 {
                        printf("%s", prev);
                        }
                        else
                        {
                                printf("\n");
                        }
                        }
                        if(u_check ==1 && d_check != 1)
                        {
                                if(num == 1)
                                {
                                        printf("%s", prev);
                                }
                                else
                                {
                                        printf("\n");
                                }
                        }
                        num = 1;
                        strcpy(prev,current);
                }

        }
        if(num != 0)
        {
                         if(c_check == 1)
                        {
                                printf("%d ",num);
                        }
                        if(d_check == 1 && u_check != 1)
                        {
                                if(num > 1)
                                {
                                        printf("%s", prev);
                                }
                        }
                        if(u_check ==1 && d_check != 1)
                        {
                                if(num == 1)
                                {
                                        printf("%s", prev);
                                }
                        }
                        if(u_check == 1 && d_check == 1)
                        {
                                printf("IT CANT BE DONE!");
                        }

        }
        printf("\n");

        return 0;
}
