#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int
main(int argc, char* argv[])
{
	
	int z; int x;
	int pid = fork ();
	if (pid < 0) 
	{
		printf (1, "could not fork");
    } 
    else if (pid == 0) 
    {
    	printf(1, "Start: Pirority 20\n");
    	chpr(pid, 20);
	   for(z = 0; z < 4000000; z+=1)
		   x = x + 3.14*89.64; //Useless calculation to consume CPU Time
	   for(z = 0; z < 4000000; z+=1)
		   x = x + 3.14*89.64; //Useless calculation to consume CPU Time
	   printf(1, "End: Priority 20\n");
     } 
     else 
     { 
	  pid = fork();
	  if (pid < 0) 
	  {
	  	printf (1, "could not fork");
      } 
      else if (pid == 0) 
      {
      		printf(1,"Start: Priority 10\n");
      		chpr(pid,10);
		   for(z = 0; z < 4000000; z+=1)
			   x = x + 3.14*89.64; //Useless calculation to consume CPU Time
		   for(z = 0; z < 4000000; z+=1)
			   x = x + 3.14*89.64; //Useless calculation to consume CPU Time
			printf(1, "End: Priority 10\n");
       } 
       else {
		printf (1, "parent waiting\n");
		int i;
		for (i = 0; i < 2; i++)
			wait();
	}
	
	}
	exit();
}


