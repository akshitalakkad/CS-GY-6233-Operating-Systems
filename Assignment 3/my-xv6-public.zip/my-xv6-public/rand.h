void sgenrand(unsigned long);
long genrand(void);
long random_at_most(long);
