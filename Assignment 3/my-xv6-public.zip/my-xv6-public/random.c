#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int main(int argc, char *argv[])
{
  int rnum, i;
  int dist[100];
  for(i=0; i<100; ++i) {
     dist[i] = 0;
  }

  for(i=0; i<100000; ++i){
    rnum = random(0,99);
    ++dist[rnum];
  }

  for(i=0; i<100; ++i)
     printf(1,"no of %d is %d\n", i, dist[i]);
 
  exit();
}

